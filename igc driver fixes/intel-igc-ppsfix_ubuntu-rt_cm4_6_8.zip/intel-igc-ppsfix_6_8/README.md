# Intel IGC PPS Fix for Kernel 6.8 (Ubuntu Realtime)

Patched igc driver based on Ubuntu Linux 6.8.0 with PPS input/output fixes for the TimeHAT I226 NIC.

## PPS Fixes Applied

1. **EXTTS (PPS Input):** Bypasses strict dual-edge flag requirement, forces rising-edge only. The I226 timestamps both edges, so the interrupt handler reads the SDP level and drops falling-edge events. Module parameters: `edge_check_invert` (default 0; 1 flips the level check) and `edge_check_delay_us` (default 0; delay before the level read).
2. **PEROUT (PPS Output):** Fixes 1PPS output so `testptp -p 1000000000` produces proper pulses instead of 1Hz square wave
3. **Pin Tracking:** Adds per-channel EXTTS pin and flags tracking

## Install

```bash
sudo apt install -y dkms linux-headers-$(uname -r)

sudo dkms remove igc -v 6.8.0-ppsfix.1 --all 2>/dev/null   # earlier build, if present
sudo dkms add .
sudo dkms build --force igc -v 6.8.0-ppsfix.2
sudo dkms install --force igc -v 6.8.0-ppsfix.2

# Replace stock module
sudo cp /lib/modules/$(uname -r)/kernel/drivers/net/ethernet/intel/igc/igc.ko.zst \
        /lib/modules/$(uname -r)/kernel/drivers/net/ethernet/intel/igc/igc.ko.zst.bak
sudo cp /lib/modules/$(uname -r)/updates/dkms/igc.ko.zst \
        /lib/modules/$(uname -r)/kernel/drivers/net/ethernet/intel/igc/igc.ko.zst
sudo depmod -a
sudo update-initramfs -u -k $(uname -r)
sudo reboot
```

## Test

```bash
sudo testptp -d /dev/ptp0 -L0,2          # pin 0 as perout
sudo testptp -d /dev/ptp0 -p 1000000000  # 1PPS output
sudo testptp -d /dev/ptp0 -L1,1          # pin 1 as extts
sudo testptp -d /dev/ptp0 -e 5           # read 5 timestamps
```
